/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>

@class SDCBarcodeAr;
@class SDCBarcodeArView;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * A deserializer to construct Barcode AR views from JSON.
 */
NS_SWIFT_NAME(BarcodeArViewDeserializer)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeArViewDeserializer : NSObject

/**
 * Added in version 7.1.0
 *
 * Constructs a new SDCBarcodeArView object with the provided JSON serialization.
 */
- (nullable SDCBarcodeArView *)viewFromJSONString:(NSString *)JSONString
                                       parentView:(nonnull UIView *)parentView
                                             mode:(SDCBarcodeAr *)mode
                                            error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 7.1.0
 *
 * Updates the view according to a JSON serialization.
 */
- (nullable SDCBarcodeArView *)updateView:(SDCBarcodeArView *)view
                           fromJSONString:(nonnull NSString *)JSONString
                                    error:(NSError *_Nullable *_Nullable)error;

@end

NS_ASSUME_NONNULL_END

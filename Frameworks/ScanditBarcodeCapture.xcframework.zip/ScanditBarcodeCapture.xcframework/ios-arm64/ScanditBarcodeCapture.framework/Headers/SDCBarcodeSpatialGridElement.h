/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCBarcode;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * Object representing an element in the grid presented by BarcodeSpatialGrid. Always contains a mainBarcode
 * barcode property; may contain the optional subBarcode barcode property.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeSpatialGridElement)
@interface SDCBarcodeSpatialGridElement : NSObject

/**
 * Added in version 7.1.0
 *
 * The main barcode associated with the element.
 */
@property (nonatomic, nonnull, readonly) SDCBarcode *mainBarcode;
/**
 * Added in version 7.1.0
 *
 * The sub/tote barcode associated with the element, if present.
 */
@property (nonatomic, nullable, readonly) SDCBarcode *subBarcode;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

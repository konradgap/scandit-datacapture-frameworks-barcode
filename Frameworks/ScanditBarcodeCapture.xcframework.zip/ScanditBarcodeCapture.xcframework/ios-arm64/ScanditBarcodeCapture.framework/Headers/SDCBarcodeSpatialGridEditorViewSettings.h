/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <ScanditCaptureCore/SDCBase.h>

@class UIColor;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 */
NS_SWIFT_NAME(BarcodeSpatialGridEditorViewSettings)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeSpatialGridEditorViewSettings : NSObject

/**
 * Added in version 7.1.0
 *
 * Configures the text of the hint that suggests to the user to drag to reorder totes.
 */
@property (nonatomic, strong) NSString *reorderHintText;
/**
 * Added in version 7.1.0
 *
 * Configures the format used to describe the position of the totes. The format used can contain {position}, if present it will be substituted with the tote index. If {position} is not found then the text will be treated as a prefix for the tote index.
 */
@property (nonatomic, strong) NSString *toteTextFormat;
/**
 * Added in version 7.1.0
 *
 * Configures the text of the button used to finish the editing.
 */
@property (nonatomic, strong) NSString *finishMappingButtonText;
/**
 * Added in version 7.1.0
 *
 * Configures the text of the button used to cancel the editing.
 */
@property (nonatomic, strong) NSString *cancelMappingButtonText;
/**
 * Added in version 7.1.0
 *
 * Configures the color of the main tote.
 */
@property (nonatomic, strong) UIColor *toteColor;
/**
 * Added in version 7.1.0
 *
 * Configures the color of the subtote.
 */
@property (nonatomic, strong) UIColor *subColor;

@end

NS_ASSUME_NONNULL_END

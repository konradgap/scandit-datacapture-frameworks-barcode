/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;

/**
 * Added in version 7.1.0
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArPopoverAnnotationButton)
@interface SDCBarcodeArPopoverAnnotationButton : UIView

/**
 * Added in version 7.1.0
 *
 * Whether the button is enabled. Default is YES.
 */
@property (nonatomic, assign, getter=isEnabled) BOOL enabled;
/**
 * Added in version 7.1.0
 *
 * The color of the text. Default is #3D4852.
 */
@property (nonatomic, strong) UIColor *textColor;
/**
 * Added in version 7.1.0
 *
 * The font used for the text. Default is semi-bold system font of size 10.
 */
@property (nonatomic, strong) UIFont *font;

/**
 * Added in version 7.1.0
 *
 * Constructs a new instance with the given icon and text.
 */
- (instancetype)initWithIcon:(SDCScanditIcon *)icon text:(NSString *)text NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

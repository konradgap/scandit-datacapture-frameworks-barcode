/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>

#import <ScanditBarcodeCapture/SDCBarcodeArCircleHighlight.h>
#import <ScanditBarcodeCapture/SDCBarcodeArInfoAnnotation.h>

@class SDCDataCaptureContext;
@class SDCBarcodeAr;
@class SDCBarcodeArDeserializer;
@class SDCBarcodeArView;
@class SDCBarcodeArSettings;
@class SDCJSONValue;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * The delegate for the BarcodeAr deserializer.
 */
NS_SWIFT_NAME(BarcodeArDeserializerDelegate)
@protocol SDCBarcodeArDeserializerDelegate <NSObject>

@optional

/**
 * Added in version 7.1.0
 *
 * Called before the deserialization of BarcodeAr is started. This is the point to overwrite defaults before the deserialization is performed.
 */
- (void)barcodeArDeserializer:(SDCBarcodeArDeserializer *)deserializer
    didStartDeserializingMode:(SDCBarcodeAr *)mode
                fromJSONValue:(SDCJSONValue *)JSONValue;

/**
 * Added in version 7.1.0
 *
 * Called when the deserialization of BarcodeAr is finished. This is the point to do additional deserialization.
 */
- (void)barcodeArDeserializer:(SDCBarcodeArDeserializer *)deserializer
    didFinishDeserializingMode:(SDCBarcodeAr *)mode
                 fromJSONValue:(SDCJSONValue *)JSONValue;

/**
 * Added in version 7.1.0
 *
 * Called before the deserialization of the BarcodeAr settings is started. This is the point to overwrite defaults before the deserialization is performed.
 */
- (void)barcodeArDeserializer:(SDCBarcodeArDeserializer *)deserializer
    didStartDeserializingSettings:(SDCBarcodeArSettings *)settings
                    fromJSONValue:(SDCJSONValue *)JSONValue;

/**
 * Added in version 7.1.0
 *
 * Called when the deserialization of the BarcodeAr settings is finished. This is the point to do additional deserialization.
 */
- (void)barcodeArDeserializer:(SDCBarcodeArDeserializer *)deserializer
    didFinishDeserializingSettings:(SDCBarcodeArSettings *)settings
                     fromJSONValue:(SDCJSONValue *)JSONValue;

@end

/**
 * Added in version 7.1.0
 *
 * A deserializer to construct Barcode AR settings and mode from JSON.
 */
NS_SWIFT_NAME(BarcodeArDeserializer)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeArDeserializer : NSObject

/**
 * Added in version 7.1.0
 *
 * The object informed about deserialization events.
 */
@property (nonatomic, weak, nullable) id<SDCBarcodeArDeserializerDelegate> delegate;

/**
 * Added in version 7.1.0
 *
 * Constructs a new SDCBarcodeArSettings object with the provided JSON serialization.
 */
- (nullable SDCBarcodeArSettings *)settingsFromJSONString:(NSString *)JSONString
                                                    error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 7.1.0
 *
 * Updates the settings according to a JSON serialization.
 */
- (nullable SDCBarcodeArSettings *)updateSettings:(SDCBarcodeArSettings *)settings
                                   fromJSONString:(NSString *)JSONString
                                            error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 7.1.0
 *
 * Constructs a new SDCBarcodeAr object with the provided JSON serialization.
 */
- (nullable SDCBarcodeAr *)modeFromJSONString:(NSString *)JSONString
                                      context:(SDCDataCaptureContext *)context
                                        error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 7.1.0
 *
 * Updates the mode according to a JSON serialization.
 */
- (nullable SDCBarcodeAr *)updateMode:(SDCBarcodeAr *)mode
                       fromJSONString:(NSString *)JSONString
                                error:(NSError *_Nullable *_Nullable)error;

@end

SDC_EXTERN NSString *NSStringFromBarcodeArCircleHighlightPreset(SDCBarcodeArCircleHighlightPreset preset) NS_SWIFT_NAME(getter:SDCBarcodeArCircleHighlightPreset.jsonString(self:));
SDC_EXTERN BOOL SDCBarcodeArCircleHighlightPresetFromJSONString(NSString *_Nonnull JSONString, SDCBarcodeArCircleHighlightPreset *preset);
SDC_EXTERN NSString *NSStringFromBarcodeArAnnotationTrigger(SDCBarcodeArAnnotationTrigger trigger) NS_SWIFT_NAME(getter:SDCBarcodeArAnnotationTrigger.jsonString(self:));
SDC_EXTERN BOOL SDCBarcodeArAnnotationTriggerFromJSONString(NSString *_Nonnull JSONString, SDCBarcodeArAnnotationTrigger *trigger);
SDC_EXTERN NSString *NSStringFromBarcodeArInfoAnnotationWidthPreset(SDCBarcodeArInfoAnnotationWidthPreset width) NS_SWIFT_NAME(getter:SDCBarcodeArInfoAnnotationWidthPreset.jsonString(self:));
SDC_EXTERN BOOL SDCBarcodeArInfoAnnotationWidthPresetFromJSONString(NSString *_Nonnull JSONString, SDCBarcodeArInfoAnnotationWidthPreset *width);
SDC_EXTERN NSString *NSStringFromBarcodeArInfoAnnotationAnchor(SDCBarcodeArInfoAnnotationAnchor anchor) NS_SWIFT_NAME(getter:SDCBarcodeArInfoAnnotationAnchor.jsonString(self:));
SDC_EXTERN BOOL SDCBarcodeArInfoAnnotationAnchorFromJSONString(NSString *_Nonnull JSONString, SDCBarcodeArInfoAnnotationAnchor *anchor);

NS_ASSUME_NONNULL_END

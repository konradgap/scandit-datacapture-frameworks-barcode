/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

@class SDCTrackedBarcode;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * The Barcode AR session holds the ongoing state of a running SDCBarcodeAr.
 *
 * @remark This class cannot be instantiated directly. Use the appropriate methods in SDCBarcodeAr to obtain instances of this class.
 */
NS_SWIFT_NAME(BarcodeArSession)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeArSession : NSObject

/**
 * Added in version 7.1.0
 *
 * Newly tracked barcodes.
 */
@property (nonatomic, strong, readonly) NSArray<SDCTrackedBarcode *> *addedTrackedBarcodes;
/**
 * Added in version 7.1.0
 *
 * A map from identifiers to barcodes. It contains all currently tracked barcodes.
 */
@property (nonatomic, strong, readonly) NSDictionary<NSNumber *, SDCTrackedBarcode *> *trackedBarcodes NS_REFINED_FOR_SWIFT;
/**
 * Added in version 7.1.0
 *
 * An array of identifiers of lost barcodes that were removed in the last frame.
 */
@property (nonatomic, strong, readonly) NSArray<NSNumber *> *removedTrackedBarcodes NS_REFINED_FOR_SWIFT;
/**
 * Added in version 7.1.0
 *
 * Returns the JSON representation of the Barcode AR session.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 7.1.0
 *
 * Resets the session, clearing all barcodes and their states.
 */
- (void)reset;

@end

NS_ASSUME_NONNULL_END

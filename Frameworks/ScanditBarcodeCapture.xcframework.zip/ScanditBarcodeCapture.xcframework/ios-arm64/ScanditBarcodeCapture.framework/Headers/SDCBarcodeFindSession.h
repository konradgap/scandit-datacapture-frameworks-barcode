/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCTrackedBarcode;

/**
 * Added in version 7.4.0
 */
NS_SWIFT_NAME(BarcodeFindSession)
SDC_EXPORTED_SYMBOL
@protocol SDCBarcodeFindSession <NSObject>

/**
 * Added in version 7.4.0
 *
 * Returns a JSON string representation of the barcode find session.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

/**
 * Added in version 7.4.0
 *
 * An array containing all the tracked barcodes.
 */
@property (nonatomic, strong, readonly) NSArray<SDCTrackedBarcode *> *trackedBarcodes;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@protocol SDCFrameData;
@class SDCBarcodeAr;
@class SDCBarcodeArSession;
@class SDCBarcodeArSettings;
@class SDCDataCaptureContext;
@class SDCBarcodeArFeedback;
@class SDCCameraSettings;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * Delegate protocol for BarcodeAr.
 *
 * This method is invoked from a recognition internal thread. To perform UI work, you must dispatch to the main thread first.
 */
NS_SWIFT_NAME(BarcodeArListener)
@protocol SDCBarcodeArListener <NSObject>

@optional

/**
 * Added in version 7.1.0
 *
 * Invoked whenever the session has been updated.
 */
- (void)barcodeAr:(SDCBarcodeAr *)barcodeAr
    didUpdateSession:(SDCBarcodeArSession *)session
           frameData:(id<SDCFrameData>)frameData;

@end

/**
 * Added in version 7.1.0
 *
 * Capture mode that implements Barcode AR.
 */
NS_SWIFT_NAME(BarcodeAr)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeAr : NSObject

/**
 * Added in version 7.1.0
 *
 * Instance of SDCBarcodeArFeedback that is used by the barcode scanner to notify users about Ar events.
 *
 * The default instance of the Feedback will have both sound and vibration enabled. A default beep sound will be used for the sound.
 */
@property (nonatomic, strong, nonnull) SDCBarcodeArFeedback *feedback;
/**
 * Added in version 7.1.0
 *
 * Returns the recommended camera settings for use with Barcode AR.
 */
@property (class, nonatomic, nonnull, readonly) SDCCameraSettings *recommendedCameraSettings;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 7.1.0
 *
 * Construct a new BarcodeAr instance with the provided settings.
 */
+ (instancetype)barcodeArWithContext:(nullable SDCDataCaptureContext *)context
                            settings:(nonnull SDCBarcodeArSettings *)settings
    NS_SWIFT_NAME(init(context:settings:));

/**
 * Added in version 7.1.0
 *
 * Asynchronously applies the new settings to the barcode scanner. If the scanner is currently running, the task will complete when the next frame is processed, and will use the new settings for that frame. If the scanner is currently not running, the task will complete as soon as the settings have been stored and won’t wait until the next frame is going to be processed.
 */
- (void)applySettings:(nonnull SDCBarcodeArSettings *)settings
    completionHandler:(nullable void (^)(void))completionHandler;

/**
 * Added in version 7.1.0
 *
 * Adds a listener to receive Barcode AR events.
 *
 * In case the same listener is already observing this instance, calling this method will not add the listener again. The listener is stored using a weak reference and must thus be retained by the caller for it to not go out of scope.
 */
- (void)addListener:(nonnull id<SDCBarcodeArListener>)listener NS_SWIFT_NAME(addListener(_:));
/**
 * Added in version 7.1.0
 *
 * Removes a previously added listener from this BarcodeAr instance.
 *
 * In case the listener is not currently observing this instance, calling this method has no effect.
 */
- (void)removeListener:(nonnull id<SDCBarcodeArListener>)listener NS_SWIFT_NAME(removeListener(_:));

@end

NS_ASSUME_NONNULL_END

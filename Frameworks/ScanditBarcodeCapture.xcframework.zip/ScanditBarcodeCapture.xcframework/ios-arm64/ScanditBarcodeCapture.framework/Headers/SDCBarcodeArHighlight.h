/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCQuadrilateral.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * Common interface for Barcode AR highlights.
 * Highlights let the user identify the scanned barcode.
 * They are shown on top of the respective barcode and are displayed as soon as the respective barcode is scanned.
 * They are available in different shapes and have configurable styles.
 * Currently, two types of highlights are supported: SDCBarcodeArCircleHighlight and SDCBarcodeArRectangleHighlight.
 */
NS_SWIFT_NAME(BarcodeArHighlight)
@protocol SDCBarcodeArHighlight <NSObject>

/**
 * Added in version 7.3.0
 *
 * Called to update the view with barcode location. Called from the main thread. This method should not be called directly, it will be invoked automatically when needed.
 */
- (void)updateWithBarcodeLocation:(SDCQuadrilateral)location NS_SWIFT_NAME(update(with:));

@end

NS_ASSUME_NONNULL_END

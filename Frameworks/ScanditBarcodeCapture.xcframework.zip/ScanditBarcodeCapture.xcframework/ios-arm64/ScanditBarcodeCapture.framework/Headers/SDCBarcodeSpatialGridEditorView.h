/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCBarcodeSpatialGrid;
@class SDCBarcodeSpatialGridEditorView;
@class SDCBarcodeSpatialGridEditorViewSettings;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 */
NS_SWIFT_NAME(BarcodeSpatialGridEditorViewDelegate)
SDC_EXPORTED_SYMBOL
@protocol SDCBarcodeSpatialGridEditorViewDelegate <NSObject>

/**
 * Added in version 7.1.0
 *
 * Called when the user has finished editing, the edited SDCBarcodeSpatialGrid is passed as parameter.
 */
- (void)barcodeSpatialGridEditorView:(SDCBarcodeSpatialGridEditorView *)view
     didFinishEditingWithSpatialGrid:(SDCBarcodeSpatialGrid *)spatialGrid;

/**
 * Added in version 7.1.0
 *
 * Called when the user wants to cancel the editing.
 */
- (void)didCancelEditingInBarcodeSpatialGridEditorView:(SDCBarcodeSpatialGridEditorView *)view;

@end

/**
 * Added in version 7.1.0
 *
 * BarcodeSpatialGridEditorView is best used in portrait.
 */
NS_SWIFT_NAME(BarcodeSpatialGridEditorView)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeSpatialGridEditorView : UIView

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

/**
 * Added in version 7.1.0
 *
 * Initializes a SDCBarcodeSpatialGridEditorView. Pass the SDCBarcodeSpatialGrid to be edited and the SDCBarcodeSpatialGridEditorViewSettings to customize the interface.
 *
 * Only accepts grids of 4 rows by 2 columns. Other grid dimensions will throw an error.
 */
+ (nullable instancetype)viewWithFrame:(CGRect)frame
                                  grid:(SDCBarcodeSpatialGrid *)grid
                              settings:(SDCBarcodeSpatialGridEditorViewSettings *)settings
                                 error:(NSError **)error;

/**
 * Added in version 7.1.0
 *
 * Set this delegate to handle events from the SDCBarcodeSpatialGridEditorView. For example the signal from the user that the editing is finished or cancelled.
 */
@property (nonatomic, weak) id<SDCBarcodeSpatialGridEditorViewDelegate> delegate;

@end

NS_ASSUME_NONNULL_END

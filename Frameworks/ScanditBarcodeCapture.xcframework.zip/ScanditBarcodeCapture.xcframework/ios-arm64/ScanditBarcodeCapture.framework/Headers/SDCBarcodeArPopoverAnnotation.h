/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArAnnotation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCBarcodeArPopoverAnnotation;
@class SDCBarcodeArPopoverAnnotationButton;

/**
 * Added in version 7.2.0
 *
 * The available anchor options for a popover annotation.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBarcodeArPopoverAnnotationAnchor) {
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its top-center point.
     */
    SDCBarcodeArPopoverAnnotationAnchorTop,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its bottom-center point.
     */
    SDCBarcodeArPopoverAnnotationAnchorBottom,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its left edge.
     */
    SDCBarcodeArPopoverAnnotationAnchorLeft,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its right edge.
     */
    SDCBarcodeArPopoverAnnotationAnchorRight
} NS_SWIFT_NAME(BarcodeArPopoverAnnotationAnchor);

/**
 * Added in version 7.1.0
 *
 * The delegate for the popover annotation.
 */
NS_SWIFT_NAME(BarcodeArPopoverAnnotationDelegate)
@protocol SDCBarcodeArPopoverAnnotationDelegate <NSObject>

@optional

/**
 * Added in version 7.1.0
 *
 * Called when a button is tapped. The buttonIndex parameter can be used to identify which button was tapped. Called only if SDCBarcodeArPopoverAnnotation.isEntirePopoverTappable is NO.
 */
- (void)barcodeArPopoverAnnotation:(SDCBarcodeArPopoverAnnotation *)annotation
                      didTapButton:(SDCBarcodeArPopoverAnnotationButton *)button
                           atIndex:(NSInteger)index;

/**
 * Added in version 7.1.0
 *
 * Called when the popover is tapped. Called only if SDCBarcodeArPopoverAnnotation.isEntirePopoverTappable is YES.
 */
- (void)barcodeArPopoverAnnotationDidTap:(SDCBarcodeArPopoverAnnotation *)annotation;

@end

/**
 * Added in version 7.1.0
 *
 * An annotation comprising a set of buttons, each containing an icon and text, which appears only when the user taps on the corresponding barcode highlight.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArPopoverAnnotation)
@interface SDCBarcodeArPopoverAnnotation : UIView <SDCBarcodeArAnnotation>

/**
 * Added in version 7.1.0
 *
 * Returns the barcode provided in the constructor.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.1.0
 *
 * The trigger that causes the annotation to be presented. By default is SDCBarcodeArAnnotationTriggerHighlightTap.
 */
@property (nonatomic, assign) SDCBarcodeArAnnotationTrigger annotationTrigger;
/**
 * Added in version 7.2.0
 *
 * The annotation anchor. The default value is SDCBarcodeArPopoverAnnotationAnchorBottom.
 */
@property (nonatomic, assign) SDCBarcodeArPopoverAnnotationAnchor anchor;
/**
 * Added in version 7.1.0
 *
 * If NO each individual button in the popover is tappable. If YES the entire popover is tappable. Default is NO.
 */
@property (nonatomic, assign) BOOL isEntirePopoverTappable;
/**
 * Added in version 7.1.0
 *
 * Returns the buttons provided in the constructor.
 */
@property (nonatomic, strong, readonly) NSArray<SDCBarcodeArPopoverAnnotationButton *> *buttons;
/**
 * Added in version 7.1.0
 *
 * An object that receives notifications for UI-related events, such as tapping on a button.
 */
@property (nonatomic, weak) id<SDCBarcodeArPopoverAnnotationDelegate> delegate;

/**
 * Added in version 7.1.0
 *
 * Constructs a new instance with the given buttons and barcode.
 */
- (instancetype)initWithBarcode:(SDCBarcode *)barcode
                        buttons:(NSArray<SDCBarcodeArPopoverAnnotationButton *> *)buttons
    NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArAnnotation.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;
@class SDCBarcode;

/**
 * Added in version 7.2.0
 *
 * The available anchor options for a status icon annotation.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBarcodeArStatusIconAnnotationAnchor) {
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its top-center point.
     */
    SDCBarcodeArStatusIconAnnotationAnchorTop,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its bottom-center point.
     */
    SDCBarcodeArStatusIconAnnotationAnchorBottom,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its left edge.
     */
    SDCBarcodeArStatusIconAnnotationAnchorLeft,
/**
     * Added in version 7.2.0
     *
     * The annotation is anchored at its right edge.
     */
    SDCBarcodeArStatusIconAnnotationAnchorRight
} NS_SWIFT_NAME(BarcodeArStatusIconAnnotationAnchor);

/**
 * Added in version 7.1.0
 *
 * A tooltip annotation that toggles between collapsed and expanded states upon tap. In the collapsed state, only the icon is visible. In the expanded state, both the icon and text are displayed.
 *
 * Collapsed state.
 *
 * Expanded state.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArStatusIconAnnotation)
@interface SDCBarcodeArStatusIconAnnotation : UIView <SDCBarcodeArAnnotation>

/**
 * Added in version 7.1.0
 *
 * The barcode instance for the annotation.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.1.0
 *
 * The trigger that causes the annotation to be presented. By default is SDCBarcodeArAnnotationTriggerHighlightTapAndBarcodeScan.
 */
@property (nonatomic, assign) SDCBarcodeArAnnotationTrigger annotationTrigger;
/**
 * Added in version 7.2.0
 *
 * The annotation anchor. The default value is SDCBarcodeArStatusIconAnnotationAnchorBottom.
 */
@property (nonatomic, assign, readwrite) SDCBarcodeArStatusIconAnnotationAnchor anchor;
/**
 * Added in version 7.1.0
 *
 * Whether the status icon has a tip. Default is YES.
 */
@property (nonatomic, assign, readwrite) BOOL hasTip;
/**
 * Added in version 7.1.0
 *
 * The icon. Default value is black SDCScanditIconTypeExclamationMark, over a SDCScanditIconShapeCircle background shape with a background color of #FBC02C.
 */
@property (nonatomic, strong, readwrite) SDCScanditIcon *icon;
/**
 * Added in version 7.1.0
 *
 * The text shown in the expanded state. Maximum allowed length is 20 characters, including whitespaces. If nil, the status icon doesn’t expand on tap. Default is nil.
 */
@property (nonatomic, strong, nullable, readwrite) NSString *text;
/**
 * Added in version 7.1.0
 *
 * The color of the text. Default is #121619.
 */
@property (nonatomic, strong, readwrite) UIColor *textColor;
/**
 * Added in version 7.1.0
 *
 * The annotation background color. Default is #FFFFFF.
 */
@property (nonatomic, strong) UIColor *backgroundColor;

/**
 * Added in version 7.1.0
 *
 * Constructs a new instance of this class.
 */
- (instancetype)initWithBarcode:(SDCBarcode *)barcode NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

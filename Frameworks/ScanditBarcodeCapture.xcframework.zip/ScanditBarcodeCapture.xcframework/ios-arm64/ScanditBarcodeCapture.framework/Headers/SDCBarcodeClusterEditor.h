/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

@class SDCCluster;
@class SDCBarcode;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * Allows edition of clusters.
 * If SDCBarcodeCountSettings.clusteringMode is set to SDCClusteringModeDisabled,
 * the methods in this class will do nothing.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeClusterEditor)
@interface SDCBarcodeClusterEditor : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 7.1.0
 *
 * Dissolves the cluster.
 */
- (void)dissolveCluster:(SDCCluster *)cluster;
/**
 * Added in version 7.1.0
 *
 * Forms a cluster from the provided barcodes. This operation will fail if one of the barcodes
 * is already part of a cluster.
 */
- (void)formCluster:(NSArray<SDCBarcode *> *)barcodes;
/**
 * Added in version 7.1.0
 *
 * Notifies the editor that the user has finished cluster edition.
 * Calling this is required in order to resume manual clustering.
 */
- (void)endEditing;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <ScanditCaptureCore/SDCBase.h>

/**
 * Added in version 7.1.0
 *
 * An enumeration of the clustering modes available.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCClusteringMode) {
/**
     * Added in version 7.1.0
     *
     * No clustering is performed.
     */
    SDCClusteringModeDisabled,
/**
     * Added in version 7.1.0
     *
     * Manual clustering is supported. The user can select barcodes which barcodes to cluster using the on-screen UI.
     */
    SDCClusteringModeManual,
/**
     * Added in version 7.1.0
     *
     * Clustering is automatically performed and cannot be manually tuned.
     */
    SDCClusteringModeAuto,
/**
     * Added in version 7.1.0
     *
     * Clustering is performed automatically, but clusters can also be formed or dissolved manually using the UI.
     */
    SDCClusteringModeAutoWithManualCorrection
} NS_SWIFT_NAME(ClusteringMode);

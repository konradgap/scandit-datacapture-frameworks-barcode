/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCTrackedBarcode;

NS_SWIFT_NAME(BarcodeSequenceSession)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeSequenceSession : NSObject

@property (nonatomic, strong, readonly)
    NSDictionary<NSNumber *, SDCTrackedBarcode *> *trackedBarcodes NS_REFINED_FOR_SWIFT;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

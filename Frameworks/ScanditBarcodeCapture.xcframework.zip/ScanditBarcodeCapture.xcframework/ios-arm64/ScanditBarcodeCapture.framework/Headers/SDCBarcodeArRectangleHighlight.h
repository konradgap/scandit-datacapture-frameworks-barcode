/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArHighlight.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;
@class SDCBarcode;
@class SDCBrush;

/**
 * Added in version 7.1.0
 *
 * A type of highlight that draws rectangles on top of barcodes. Highlight styles are customizable. Here are some examples:
 *
 * Default style.
 *
 * Customized brush and icon.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArRectangleHighlight)
@interface SDCBarcodeArRectangleHighlight : UIView <SDCBarcodeArHighlight>

/**
 * Added in version 7.1.0
 *
 * The barcode instance for the annotation.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.1.0
 *
 * The icon used for visualizing a recognized barcode in the UI. Is nil by default.
 */
@property (nonatomic, strong, nullable, readwrite) SDCScanditIcon *icon;
/**
 * Added in version 7.1.0
 *
 * The brush used for visualizing a recognized barcode in the UI. By default, the brush has a blue fill color with 45% alpha, blue stroke and a stroke width of 2.
 */
@property (nonatomic, strong, readwrite) SDCBrush *brush;

/**
 * Added in version 7.1.0
 *
 * Creates a new instance with default values.
 */
- (instancetype)initWithBarcode:(SDCBarcode *)barcode NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

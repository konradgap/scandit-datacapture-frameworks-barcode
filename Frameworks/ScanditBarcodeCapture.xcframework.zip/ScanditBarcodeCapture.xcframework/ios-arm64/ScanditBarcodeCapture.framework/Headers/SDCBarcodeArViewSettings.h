/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCCamera.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 */
NS_SWIFT_NAME(BarcodeArViewSettings)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeArViewSettings : NSObject

/**
 * Added in version 7.1.0
 *
 * Indicates whether the feedback should have sound enabled.
 *
 * Default is YES.
 */
@property (nonatomic, assign) BOOL soundEnabled;
/**
 * Added in version 7.1.0
 *
 * Indicates whether the feedback should have haptics enabled.
 *
 * Default is YES.
 */
@property (nonatomic, assign) BOOL hapticEnabled;
/**
 * Added in version 7.1.0
 *
 * Sets the default camera position.
 *
 * Default is SDCCameraPositionWorldFacing.
 */
@property (nonatomic, assign) SDCCameraPosition defaultCameraPosition;
/**
 * Added in version 7.1.0
 *
 * Returns the JSON representation of the Barcode AR view settings.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;

/**
 * Added in version 7.1.0
 *
 * A component that forms the body of an info annotation. Each component represents a “row,” containing text with optional icons on the left and/or right sides.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArInfoAnnotationBodyComponent)
@interface SDCBarcodeArInfoAnnotationBodyComponent : UIView

/**
 * Added in version 7.1.0
 *
 * Whether the left icon is tappable. Default is YES.
 */
@property (nonatomic, assign) BOOL isLeftIconTappable;
/**
 * Added in version 7.1.0
 *
 * Whether the right icon is tappable. Default is YES.
 */
@property (nonatomic, assign) BOOL isRightIconTappable;
/**
 * Added in version 7.1.0
 *
 * The text shown in the component.
 */
@property (nonatomic, strong, nullable) NSString *text;
/**
 * Added in version 7.1.0
 *
 * The styled text shown in the component. When set, it overrides the values defined in the other text-related properties (text, font, textColor, textAlignment).
 */
@property (nonatomic, strong, nullable) NSAttributedString *styledText;
/**
 * Added in version 7.1.0
 *
 * The text alignment. The default value is center.
 */
@property (nonatomic, assign) NSTextAlignment textAlignment;
/**
 * Added in version 7.1.0
 *
 * The icon displayed on the left side of the component. If nil, no button is shown. The default value is nil.
 */
@property (nonatomic, strong, nullable) SDCScanditIcon *leftIcon;
/**
 * Added in version 7.1.0
 *
 * The icon displayed on the right side of the component. If nil, no button is shown. The default value is nil.
 */
@property (nonatomic, strong, nullable) SDCScanditIcon *rightIcon;
/**
 * Added in version 7.1.0
 *
 * The color of the text. The default value is #121619.
 */
@property (nonatomic, strong) UIColor *textColor;
/**
 * Added in version 7.1.0
 *
 * The font used for the text. The default value is the system font of size 14.
 */
@property (nonatomic, strong) UIFont *font;

- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

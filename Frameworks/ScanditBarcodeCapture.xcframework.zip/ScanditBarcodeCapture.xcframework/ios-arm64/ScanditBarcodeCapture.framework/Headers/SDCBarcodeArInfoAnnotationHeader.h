/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;

/**
 * Added in version 7.1.0
 *
 * The header of an info annotation.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArInfoAnnotationHeader)
@interface SDCBarcodeArInfoAnnotationHeader : UIView

/**
 * Added in version 7.1.0
 *
 * The text. Default is nil.
 */
@property (nonatomic, strong, nullable) NSString *text;
/**
 * Added in version 7.1.0
 *
 * The icon. Default is nil.
 */
@property (nonatomic, strong, nullable) SDCScanditIcon *icon;
/**
 * Added in version 7.1.0
 *
 * The color of the text. Default is #000000.
 */
@property (nonatomic, strong) UIColor *textColor;
/**
 * Added in version 7.1.0
 *
 * The font used for the text. Default is semibold system font of size 16.
 */
@property (nonatomic, strong) UIFont *font;
/**
 * Added in version 7.1.0
 *
 * The background color. Default is #00FFFF.
 */
@property (nonatomic, strong) UIColor *backgroundColor;

- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN
/**
 * Added in version 7.1.0
 *
 * Settings used with the BarcodeCount mapping flow.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeCountMappingFlowSettings)
@interface SDCBarcodeCountMappingFlowSettings : NSObject

/**
 * Added in version 7.1.0
 *
 * Text displayed for the initial guidance during the mapping flow.
 * Defaults to “Tap shutter to scan all codes in batches”.
 */
@property (nonatomic, strong) NSString *scanBarcodesGuidanceText;
/**
 * Added in version 7.1.0
 *
 * Text displayed during the mapping flow on the last screen.
 * Defaults to “Step back to fit all codes into camera view”.
 */
@property (nonatomic, strong) NSString *stepBackGuidanceText;
/**
 * Added in version 7.1.0
 *
 * Text displayed on the “Next” button.
 * Defaults to “Next”.
 */
@property (nonatomic, strong) NSString *nextButtonText;
/**
 * Added in version 7.1.0
 *
 * Text displayed on the “Redo map” button.
 * Defaults to “Redo map”.
 */
@property (nonatomic, strong) NSString *redoScanButtonText;
/**
 * Added in version 7.1.0
 *
 * Text displayed on the “Finish” button.
 * Defaults to “Finish”.
 */
@property (nonatomic, strong) NSString *finishButtonText;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCQuadrilateral.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.3.0
 *
 * A barcode or a cluster tracked over the course of multiple frames.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(TrackedObject)
@interface SDCTrackedObject : NSObject

/**
 * Added in version 7.3.0
 *
 * The data associated with this object.
 */
@property (nonatomic, nullable, readonly) NSString *data;
/**
 * Added in version 7.3.0
 *
 * The unique identifier for the tracked object. The identifier is unique for each object. The same identifier may be reused once the object is lost for another object.
 */
@property (nonatomic, readonly) NSInteger identifier;
/**
 * Added in version 7.3.0
 *
 * The location of the code. The coordinates are in image-space, meaning that the coordinates correspond to actual pixels in the image. For display, the coordinates need first to be converted into screen-space using the data capture view.
 *
 * The meaning of the values of SDCQuadrilateral.topLeft is such that the top left point corresponds to the top left corner of the barcode, independent of how the code is oriented in the image. Same for the other corners.
 */
@property (nonatomic, readonly) SDCQuadrilateral location;
/**
 * Added in version 7.3.0
 *
 * Returns the JSON representation of the tracked object.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArAnnotation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;
@class SDCBarcodeArInfoAnnotation;
@class SDCBarcodeArInfoAnnotationBodyComponent;
@class SDCBarcodeArInfoAnnotationHeader;
@class SDCBarcodeArInfoAnnotationFooter;

/**
 * Added in version 7.1.0
 *
 * The available width options for an info annotation.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBarcodeArInfoAnnotationWidthPreset) {
/**
     * Added in version 7.1.0
     *
     * Small width. Recommended for annotations that contain only text or icon, and do not include a header or footer.
     */
    SDCBarcodeArInfoAnnotationWidthPresetSmall,
/**
     * Added in version 7.1.0
     *
     * Medium width.
     */
    SDCBarcodeArInfoAnnotationWidthPresetMedium,
/**
     * Added in version 7.1.0
     *
     * Large width.
     */
    SDCBarcodeArInfoAnnotationWidthPresetLarge
} NS_SWIFT_NAME(BarcodeArInfoAnnotationWidthPreset);

/**
 * Added in version 7.1.0
 *
 * The available anchor options for an info annotation.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBarcodeArInfoAnnotationAnchor) {
/**
     * Added in version 7.1.0
     *
     * The annotation is anchored at its top-center point.
     */
    SDCBarcodeArInfoAnnotationAnchorTop,
/**
     * Added in version 7.1.0
     *
     * The annotation is anchored at its bottom-center point.
     */
    SDCBarcodeArInfoAnnotationAnchorBottom,
/**
     * Added in version 7.1.0
     *
     * The annotation is anchored at its left edge.
     */
    SDCBarcodeArInfoAnnotationAnchorLeft,
/**
     * Added in version 7.1.0
     *
     * The annotation is anchored at its right edge.
     */
    SDCBarcodeArInfoAnnotationAnchorRight
} NS_SWIFT_NAME(BarcodeArInfoAnnotationAnchor);

/**
 * Added in version 7.1.0
 *
 * The delegate for the info annotation.
 */
NS_SWIFT_NAME(BarcodeArInfoAnnotationDelegate)
@protocol SDCBarcodeArInfoAnnotationDelegate <NSObject>

@optional

/**
 * Added in version 7.1.0
 *
 * Called when the annotation header is tapped. Called only if SDCBarcodeArInfoAnnotation.isEntireAnnotationTappable is NO.
 */
- (void)barcodeArInfoAnnotationDidTapHeader:(SDCBarcodeArInfoAnnotation *)annotation;
/**
 * Added in version 7.1.0
 *
 * Called when the annotation footer is tapped. Called only if SDCBarcodeArInfoAnnotation.isEntireAnnotationTappable is NO.
 */
- (void)barcodeArInfoAnnotationDidTapFooter:(SDCBarcodeArInfoAnnotation *)annotation;
/**
 * Added in version 7.1.0
 *
 * Called when the left icon of an annotation component is tapped. componentIndex specifies the index of the component containing the tapped icon within the SDCBarcodeArInfoAnnotation.body array. Called only if SDCBarcodeArInfoAnnotation.isEntireAnnotationTappable is NO.
 */
- (void)barcodeArInfoAnnotation:(SDCBarcodeArInfoAnnotation *)annotation
     didTapLeftIconForComponent:(SDCBarcodeArInfoAnnotationBodyComponent *)component
                             at:(NSInteger)componentIndex;
/**
 * Added in version 7.1.0
 *
 * Called when the right icon of an annotation component is tapped. componentIndex specifies the index of the component containing the tapped icon within the SDCBarcodeArInfoAnnotation.body array. Called only if SDCBarcodeArInfoAnnotation.isEntireAnnotationTappable is NO.
 */
- (void)barcodeArInfoAnnotation:(SDCBarcodeArInfoAnnotation *)annotation
    didTapRightIconForComponent:(SDCBarcodeArInfoAnnotationBodyComponent *)component
                             at:(NSInteger)componentIndex;
/**
 * Added in version 7.1.0
 *
 * Called when the annotation is tapped. Called only if SDCBarcodeArInfoAnnotation.isEntireAnnotationTappable is YES.
 */
- (void)barcodeArInfoAnnotationDidTap:(SDCBarcodeArInfoAnnotation *)annotation;

@end

/**
 * Added in version 7.1.0
 *
 * Info annotations are tooltips that display text and icons, structured as an array of body components. Each body component contains text and may include optional tappable icons on both the left and right sides.
 *
 * In addition to the body components, info annotations can include an optional header, and footer. By default, they appear automatically when the corresponding barcode is scanned. Info annotations are available in three predefined widths, with their height dynamically adjusting to fit the content.
 * Here are some examples:
 *
 * Body component only.
 *
 * Body component and header.
 *
 * Body component with attributed text and tappable icon.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArInfoAnnotation)
@interface SDCBarcodeArInfoAnnotation : UIView <SDCBarcodeArAnnotation>

/**
 * Added in version 7.1.0
 *
 * The barcode instance for the annotation.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.1.0
 *
 * The trigger that causes the annotation to be presented. By default is SDCBarcodeArAnnotationTriggerHighlightTapAndBarcodeScan.
 */
@property (nonatomic, assign) SDCBarcodeArAnnotationTrigger annotationTrigger;

/**
 * Added in version 7.1.0
 *
 * Whether the annotation has a tip. The default value is YES.
 */
@property (nonatomic, assign) BOOL hasTip;
/**
 * Added in version 7.1.0
 *
 * If NO, each individual element within the annotation (header, footer, icons in body components) is tappable. If YES, the entire annotation is tappable.
 */
@property (nonatomic, assign) BOOL isEntireAnnotationTappable;
/**
 * Added in version 7.1.0
 *
 * The annotation anchor. The default value is SDCBarcodeArInfoAnnotationAnchorBottom.
 */
@property (nonatomic, assign) SDCBarcodeArInfoAnnotationAnchor anchor;
/**
 * Added in version 7.1.0
 *
 * The annotation width. The default value is SDCBarcodeArInfoAnnotationWidthPresetSmall.
 */
@property (nonatomic, assign) SDCBarcodeArInfoAnnotationWidthPreset width;
/**
 * Added in version 7.1.0
 *
 * The background color. The default value is white.
 */
@property (nonatomic, strong) UIColor *backgroundColor;

/**
 * Added in version 7.1.0
 *
 * The annotation body, represented as an array of body components. The default value is [].
 */
@property (nonatomic, strong) NSArray<SDCBarcodeArInfoAnnotationBodyComponent *> *body;
/**
 * Added in version 7.1.0
 *
 * The annotation header. The default value is nil.
 */
@property (nonatomic, strong, nullable) SDCBarcodeArInfoAnnotationHeader *header;
/**
 * Added in version 7.1.0
 *
 * The annotation footer. The default value is nil.
 */
@property (nonatomic, strong, nullable) SDCBarcodeArInfoAnnotationFooter *footer;

/**
 * Added in version 7.1.0
 *
 * An object that receives notifications for UI-related events.
 */
@property (nonatomic, weak) id<SDCBarcodeArInfoAnnotationDelegate> delegate;

/**
 * Added in version 7.1.0
 *
 * Constructs a new instance with the given barcode.
 */
- (nonnull instancetype)initWithBarcode:(SDCBarcode *)barcode NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

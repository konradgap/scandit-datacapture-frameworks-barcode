/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArHighlight.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCScanditIcon;
@class SDCBarcode;
@class SDCBrush;

/**
 * Added in version 7.1.0
 *
 * The circle highlight presets.
 */
typedef NS_CLOSED_ENUM(NSUInteger, SDCBarcodeArCircleHighlightPreset) {
/**
     * Added in version 7.1.0
     *
     * Dot style. By default a smaller blue circle.
     */
    SDCBarcodeArCircleHighlightPresetDot,
/**
     * Added in version 7.1.0
     *
     * Icon style. By default a larger blue circle.
     */
    SDCBarcodeArCircleHighlightPresetIcon
} NS_SWIFT_NAME(BarcodeArCircleHighlightPreset);

/**
 * Added in version 7.1.0
 *
 * A type of highlight that draws circles on top of barcodes. Highlight styles are customizable. Here are some examples:
 *
 * Dot preset.
 *
 * Icon preset.
 *
 * Icon preset with different border color.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArCircleHighlight)
@interface SDCBarcodeArCircleHighlight : UIView <SDCBarcodeArHighlight>

/**
 * Added in version 7.2.0
 *
 * Whether the highlight is showing a pulsing animation.
 */
@property (nonatomic, assign, readwrite) BOOL isPulsing;
/**
 * Added in version 7.1.0
 *
 * The barcode instance for the annotation.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.1.0
 *
 * The size of the circle highlight in device-independent pixels. Minimum value is 18. If specified value is less than the minimum value, it will be coerced to the minimum value.
 */
@property (nonatomic, assign, readwrite) CGFloat size;
/**
 * Added in version 7.1.0
 *
 * The icon used for visualizing a recognized barcode in the UI.
 */
@property (nonatomic, strong, nullable, readwrite) SDCScanditIcon *icon;
/**
 * Added in version 7.1.0
 *
 * The brush used for visualizing a recognized barcode in the UI. By default, the brush has a blue fill color with 45% alpha, blue stroke and a stroke width of 2.
 */
@property (nonatomic, strong, readwrite) SDCBrush *brush;

/**
 * Added in version 7.1.0
 *
 * Creates a new instance with default values for the specified preset.
 */
- (instancetype)initWithBarcode:(SDCBarcode *)barcode
                         preset:(SDCBarcodeArCircleHighlightPreset)preset NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

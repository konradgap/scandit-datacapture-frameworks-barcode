/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureMode.h>

@class SDCBarcodeSequence;
@class SDCBarcodeSequenceSettings;
@class SDCBarcodeSequenceSession;
@class SDCDataCaptureContext;
@class SDCCameraSettings;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(BarcodeSequenceListener)
@protocol SDCBarcodeSequenceListener <NSObject>

@optional

- (void)barcodeSequence:(SDCBarcodeSequence *)barcodeSequence
       didUpdateSession:(SDCBarcodeSequenceSession *)session;

@end

/**
 * Added in version 8.0.0
 *
 * Capture mode that implements BarcodeSequence.
 */
NS_SWIFT_NAME(BarcodeSequence)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeSequence : NSObject <SDCDataCaptureMode>

/**
 * Added in version 8.0.0
 *
 * The context this mode is attached to. When the data capture mode is not attached to a context, nil is returned.
 */
@property (nonatomic, nullable, readonly) SDCDataCaptureContext *context;
/**
 * Added in version 8.0.0
 *
 * This flag indicates whether the BarcodeSequence mode is currently processing frames to recognise barcodes.
 */
@property (nonatomic, assign, getter=isEnabled) BOOL enabled;
/**
 * Added in version 8.0.0
 *
 * Returns the recommended camera settings for use with Barcode Sequence.
 */
@property (class, nonatomic, nonnull, readonly) SDCCameraSettings *recommendedCameraSettings;

+ (instancetype)barcodeSequenceWithContext:(SDCDataCaptureContext *)context
                                  settings:(SDCBarcodeSequenceSettings *)settings;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 8.0.0
 *
 * Asynchronously applies the new settings to the barcode scanner. If the scanner is currently running, the task will complete when the next frame is processed, and will use the new settings for that frame. If the scanner is currently not running, the task will complete as soon as the settings have been stored and won’t wait until the next frame is going to be processed.
 */
- (void)applySettings:(nonnull SDCBarcodeSequenceSettings *)settings
    completionHandler:(nullable void (^)(void))completionHandler;

/**
 * Added in version 8.0.0
 *
 * Adds the listener to this BarcodeSequence instance.
 *
 * In case the same listener is already observing this instance, calling this method will not add the listener again. The listener is stored using a weak reference and must thus be retained by the caller for it to not go out of scope.
 */
- (void)addListener:(nonnull id<SDCBarcodeSequenceListener>)listener NS_SWIFT_NAME(addListener(_:));
/**
 * Added in version 8.0.0
 *
 * Removes a previously added listener from this BarcodeSequence instance.
 *
 * In case the listener is not currently observing this instance, calling this method has no effect.
 */
- (void)removeListener:(nonnull id<SDCBarcodeSequenceListener>)listener
    NS_SWIFT_NAME(removeListener(_:));

/**
 * Added in version 8.0.0
 *
 * Resets the barcode sequence session, clearing all currently tracked barcodes. This only affects the session; the enabled state of the mode is unchanged.
 */
- (void)reset;

@end

NS_ASSUME_NONNULL_END

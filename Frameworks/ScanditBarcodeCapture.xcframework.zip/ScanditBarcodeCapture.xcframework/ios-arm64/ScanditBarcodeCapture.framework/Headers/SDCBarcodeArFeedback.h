/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCFeedback;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * Determines what feedback (vibration, sound) should be emitted when barcodes are checked.
 *
 * The feedback is specified for each BarcodeAr instance separately and can be changed
 * through the feedback property by either modifying an existing instance of this class, or by assigning a new one.
 *
 * See documentation on the SDCBarcodeAr.feedback property for usage samples.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArFeedback)
@interface SDCBarcodeArFeedback : NSObject

/**
 * Added in version 7.1.0
 *
 * Returns a Barcode AR feedback with default configuration:
 *
 *   • default beep sound is loaded,
 *
 *   • beeping for the success event is enabled,
 *
 *   • vibration for the success event is enabled.
 */
@property (class, nonatomic, readonly) SDCBarcodeArFeedback *defaultFeedback;
/**
 * Added in version 7.1.0
 *
 * A feedback for a barcode scanned event.
 */
@property (nonatomic, strong, nonnull) SDCFeedback *scanned;
/**
 * Added in version 7.1.0
 *
 * A feedback for an element tapped event.
 */
@property (nonatomic, strong, nonnull) SDCFeedback *tapped;
/**
 * Added in version 7.1.0
 *
 * Returns the JSON representation of the feedback.
 */
@property (nonatomic, nonnull, readonly) NSString *JSONString;

/**
 * Added in version 7.1.0
 */
+ (nullable instancetype)barcodeArFeedbackFromJSONString:(nonnull NSString *)JSONString
                                                   error:(NSError *_Nullable *_Nullable)error;

/**
 * Added in version 7.1.0
 *
 * Empty constructor. Constructs a new feedback that will not emit any sound, nor vibration.
 */
- (instancetype)init;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>

@class SDCBarcode;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 *
 * A recognized cluster.
 */
NS_SWIFT_NAME(Cluster)
SDC_EXPORTED_SYMBOL
@interface SDCCluster : NSObject

/**
 * Added in version 7.1.0
 *
 * The array of barcodes that form the cluster.
 */
@property (nonatomic, strong, readonly) NSArray<SDCBarcode *> *barcodes;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCBarcode;
@protocol SDCBarcodeArHighlight;

/**
 * Added in version 7.1.0
 *
 * An object used to retrieve the highlights for scanned barcodes.
 */
NS_SWIFT_NAME(BarcodeArHighlightProvider)
@protocol SDCBarcodeArHighlightProvider <NSObject>

/**
 * Added in version 7.1.0
 *
 * Asks the provider for a highlight to display for the given barcode. If nil is provided, no highlight will be shown. This method is called on the main thread, and completionHandler must be invoked on the main thread.
 */
- (void)highlightForBarcode:(nonnull SDCBarcode *)barcode
          completionHandler:(nonnull void (^)(UIView<SDCBarcodeArHighlight> *_Nullable))completionHandler NS_SWIFT_UI_ACTOR;

@end

NS_ASSUME_NONNULL_END

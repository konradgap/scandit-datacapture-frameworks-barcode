/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCAnchor.h>
#import <ScanditCaptureCore/SDCMeasureUnit.h>

@class SDCBarcode;
@class SDCBarcodeAr;
@class SDCBarcodeArView;
@class SDCBarcodeArViewSettings;
@class SDCDataCaptureContext;
@class SDCCameraSettings;
@protocol SDCNotificationPresenter;
@protocol SDCBarcodeArHighlight;
@protocol SDCBarcodeArHighlightProvider;
@protocol SDCBarcodeArAnnotationProvider;

NS_ASSUME_NONNULL_BEGIN

/**
 * Added in version 7.1.0
 */
NS_SWIFT_NAME(BarcodeArViewUIDelegate)
@protocol SDCBarcodeArViewUIDelegate <NSObject>

@optional

/**
 * Added in version 7.1.0
 *
 * Callback method that is called when a barcode highlight is tapped in the view.
 */
- (void)barcodeAr:(SDCBarcodeAr *)barcodeAr
    didTapHighlightForBarcode:(SDCBarcode *)barcode
                    highlight:(UIView<SDCBarcodeArHighlight> *)highlight;

@end

/**
 * Added in version 7.1.0
 *
 * Barcode AR comes with a ready-to-use UI that allows highlighting barcodes and displaying additional information over them.
 * The BarcodeArView integrates with any app in just a few lines of code.
 */
NS_SWIFT_NAME(BarcodeArView)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeArView : UIView

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

/**
 * Added in version 7.1.0
 *
 * Creates a new BarcodeArView with the provided mode, viewSettings and cameraSettings.
 */
- (instancetype)initWithParentView:(nonnull UIView *)parentView
                         barcodeAr:(nonnull SDCBarcodeAr *)barcodeAr
                          settings:(nonnull SDCBarcodeArViewSettings *)settings
                    cameraSettings:(nullable SDCCameraSettings *)cameraSettings;

/**
 * Added in version 7.1.0
 *
 * Sets the delegate which is called whenever a barcode highlight is tapped in the view.
 */
@property (nonatomic, weak, nullable) id<SDCBarcodeArViewUIDelegate> UIDelegate;
/**
 * Added in version 7.1.0
 *
 * Sets the provider which supplies highlight information for barcodes in the view. If nil, a default provider is used, which returns a predefined highlight for each barcode.
 */
@property (nonatomic, weak, nullable) id<SDCBarcodeArHighlightProvider> highlightProvider;
/**
 * Added in version 7.1.0
 *
 * Sets the provider which supplies annotation information for barcodes in the view. If nil, no annotation will be displayed for any barcode.
 */
@property (nonatomic, weak, nullable) id<SDCBarcodeArAnnotationProvider> annotationProvider;
/**
 * Added in version 7.1.0
 *
 * Indicates whether the torch control button should be shown to the user.
 *
 * Default is NO.
 */
@property (nonatomic, assign, readwrite) BOOL shouldShowTorchControl;
/**
 * Added in version 7.1.0
 *
 * Updates the position of the torch control button.
 *
 * Default is SDCAnchorTopLeft.
 */
@property (nonatomic, assign, readwrite) SDCAnchor torchControlPosition;
/**
 * Added in version 7.3.0
 *
 * Sets the visual offset of the torch control button.
 *
 * Use SDCPointWithUnitNull (FloatWithUnit.null in Swift) to unset the value. Default is SDCPointWithUnitNull.
 */
@property (nonatomic, assign, readwrite) SDCPointWithUnit torchControlOffset;
/**
 * Added in version 7.1.0
 *
 * Indicates whether the zoom control button should be shown to the user.
 */
@property (nonatomic, assign, readwrite) BOOL shouldShowZoomControl;
/**
 * Added in version 7.1.0
 *
 * Updates the position of the zoom control button.
 *
 * Default is SDCAnchorBottomRight.
 */
@property (nonatomic, assign, readwrite) SDCAnchor zoomControlPosition;
/**
 * Added in version 7.3.0
 *
 * Sets the visual offset of the zoom control button.
 *
 * Use SDCPointWithUnitNull (FloatWithUnit.null in Swift) to unset the value. Default is SDCPointWithUnitNull.
 */
@property (nonatomic, assign, readwrite) SDCPointWithUnit zoomControlOffset;
/**
 * Added in version 7.1.0
 *
 * Indicates whether the camera switch control button should be shown to the user.
 */
@property (nonatomic, assign, readwrite) BOOL shouldShowCameraSwitchControl;
/**
 * Added in version 7.1.0
 *
 * Updates the position of the camera switch control button.
 *
 * Default is SDCAnchorTopRight.
 */
@property (nonatomic, assign, readwrite) SDCAnchor cameraSwitchControlPosition;
/**
 * Added in version 7.3.0
 *
 * Sets the visual offset of the camera switch control button.
 *
 * Use SDCPointWithUnitNull (FloatWithUnit.null in Swift) to unset the value. Default is SDCPointWithUnitNull.
 */
@property (nonatomic, assign, readwrite) SDCPointWithUnit cameraSwitchControlOffset;
/**
 * Added in version 7.1.0
 *
 * Indicates whether the macro mode control button should be shown to the user.
 */
@property (nonatomic, assign, readwrite) BOOL shouldShowMacroModeControl;
/**
 * Added in version 7.1.0
 *
 * Updates the position of the macro mode control button.
 *
 * Default is SDCAnchorTopRight.
 */
@property (nonatomic, assign, readwrite) SDCAnchor macroModeControlPosition;
/**
 * Added in version 7.3.0
 *
 * Sets the visual offset of the macro mode control button.
 *
 * Use SDCPointWithUnitNull (FloatWithUnit.null in Swift) to unset the value. Default is SDCPointWithUnitNull.
 */
@property (nonatomic, assign, readwrite) SDCPointWithUnit macroModeControlOffset;
/**
 * Added in version 7.5.0
 *
 * Returns a SDCNotificationPresenter instance that can be used to present notifications to the user.
 */
@property (nonatomic, strong, readonly) id<SDCNotificationPresenter> notificationPresenter;

/**
 * Added in version 7.1.0
 *
 * Starts the scanning process.
 */
- (void)start;
/**
 * Added in version 7.1.0
 *
 * Stops the scanning process.
 */
- (void)stop;
/**
 * Added in version 7.1.0
 *
 * Pauses the scanning process.
 */
- (void)pause;
/**
 * Added in version 7.1.0
 *
 * Clears all highlights and annotations currently visible and calls highlightProvider and annotationProvider to supply new highlights and annotations.
 */
- (void)reset;

@end

NS_ASSUME_NONNULL_END

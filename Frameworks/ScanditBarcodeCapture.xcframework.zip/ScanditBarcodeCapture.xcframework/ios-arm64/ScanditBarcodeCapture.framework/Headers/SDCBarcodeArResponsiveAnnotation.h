/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditBarcodeCapture/SDCBarcodeArAnnotation.h>
#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCBarcodeArInfoAnnotation;

/**
 * Added in version 7.5.0
 *
 * Responsive annotations dynamically switch between two different info annotation variations based on the barcode’s size relative to the screen. This allows for different display styles when barcodes appear close-up versus far away in the camera view.
 *
 * The annotation uses a configurable threshold to determine when to switch between the close-up and far-away variations. When the barcode area as a percentage of the screen area exceeds the threshold, the far-away annotation is displayed. Otherwise, the close-up annotation is shown.
 *
 * Both the close-up and far-away annotations are SDCBarcodeArInfoAnnotation instances, but either can be set to nil to display nothing for that variation.
 */
SDC_EXPORTED_SYMBOL
NS_SWIFT_NAME(BarcodeArResponsiveAnnotation)
@interface SDCBarcodeArResponsiveAnnotation : UIView <SDCBarcodeArAnnotation>

/**
 * Added in version 7.5.0
 *
 * The barcode instance for the annotation.
 */
@property (nonatomic, strong, readonly) SDCBarcode *barcode;
/**
 * Added in version 7.5.0
 *
 * The trigger that causes the annotation to be presented. By default is SDCBarcodeArAnnotationTriggerHighlightTapAndBarcodeScan.
 */
@property (nonatomic, assign) SDCBarcodeArAnnotationTrigger annotationTrigger;
/**
 * Added in version 7.5.0
 *
 * The threshold (percentage of the barcode area vs screen area) that determines when to display close-up vs far-away annotations.
 *
 * The value should be between 0.0 and 1.0, where 0.1 represents 10% of the screen area.
 * The default value is 0.05.
 *
 * @remark The threshold is a class-level property that applies to all instances of SDCBarcodeArResponsiveAnnotation.
 */
@property (class, nonatomic, assign, readwrite) CGFloat threshold;

/**
 * Added in version 7.5.0
 *
 * Constructs a new responsive annotation with the given barcode and annotation variations.
 */
- (instancetype)initWithBarcode:(SDCBarcode *)barcode
                        closeUp:(nullable SDCBarcodeArInfoAnnotation *)closeUpAnnotation
                        farAway:(nullable SDCBarcodeArInfoAnnotation *)farAwayAnnotation
    NS_DESIGNATED_INITIALIZER;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)coder NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END

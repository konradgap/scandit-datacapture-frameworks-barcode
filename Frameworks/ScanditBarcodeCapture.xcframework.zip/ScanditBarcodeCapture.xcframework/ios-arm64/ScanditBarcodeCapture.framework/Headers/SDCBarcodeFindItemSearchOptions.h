/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2017- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <ScanditCaptureCore/SDCBase.h>

NS_ASSUME_NONNULL_BEGIN

@class SDCBrush;

/**
 * Added in version 6.18.0
 *
 * An object that defines the search options.
 */
NS_SWIFT_NAME(BarcodeFindItemSearchOptions)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeFindItemSearchOptions : NSObject

/**
 * Added in version 7.1.0
 *
 * The barcode data as a binary blob.
 */
@property (nonatomic, readonly) NSData *barcodeRawData;
/**
 * Added in version 6.18.0
 *
 * The barcode data as a string.
 */
@property (nonatomic, readonly) NSString *barcodeData;
/**
 * Added in version 7.1.0
 *
 * The SDCBrush to be applied to the dot shown over the barcode, when detected.
 */
@property (nonatomic, nullable, readonly) SDCBrush *brush;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Added in version 6.18.0
 *
 * Create a new BarcodeFindItemSearchOptions object with the provided barcode data.
 */
- (instancetype)initWithBarcodeData:(NSString *)data;
/**
 * Added in version 7.1.0
 *
 * Create a new BarcodeFindItemSearchOptions object with the provided barcode data and a custom SDCBrush to be applied to the shown dot.
 */
- (instancetype)initWithBarcodeData:(NSString *)data brush:(nullable SDCBrush *)brush;
/**
 * Added in version 6.18.0
 *
 * Create a new BarcodeFindItemSearchOptions object with the provided barcode data.
 */
- (instancetype)initWithBarcodeRawData:(NSData *)data;
/**
 * Added in version 7.1.0
 *
 * Create a new BarcodeFindItemSearchOptions object with the provided barcode data and a custom SDCBrush to be applied to the shown dot.
 */
- (instancetype)initWithBarcodeRawData:(NSData *)data
                                 brush:(nullable SDCBrush *)brush NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
